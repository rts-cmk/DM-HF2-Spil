"use strict";
var totalNumTurns=0;
var flipVal=0;
var turned=[];
var finished=[];
var symbolList=[];


    /* I denne app får jeg brug for at kunne blande rækkefølgen af elementer i et array tilfældigt.
    * Men da Array-objekter ikke har en 'randomize' metode, har jeg udvidet denne type med en 'randomize()'
    * med en 'randomize' metode */
Array.prototype.randomize=function(){
    var i = this.length, j, temp;   // Antal ementer i arrayet
    while (--i > 0) {
        j = Math.floor(Math.random() * (i + 1));
        temp = this[j];
        this[j] = this[i];
        this[i] = temp;
    }
}
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
function gameInit(){
    totalNumTurns=0;    // Tællevariabel til antal vendte kort
    flipVal=[];         // Værdien på det vendte kort
    finished=[];        // Listen af alle vendte kort der er parrede
    symbolList=[];      // Array til listen af de billeder (filnavne) der  anvendes
    var content='<div>Klik på en boks for at vende den<br>\
                    Hvis den næste boks du klikker på<br>\
                    matcher den forrrige boks<br>\
                    bliver boksparret stående\
                </div>';
        
    for(var i = 0; i < 12; i++){
        // De tolv billeder i 'img' mappen er navngivet 'place{n}.png' hvor n = {0,1,2...11}
        // Resultatet bliver et array af formen:
        //    ['place0.png', 'place0.png','place1.png','place1.png',...,'place11.png', 'place11.png']
        symbolList.push(`img/place${i}.png`);
        symbolList.push(`img/place${i}.png`);
    }
    symbolList.randomize(); // Bland alle fliser i tilfældig rækkefølge
    var randCol;
    for(var i=0,j=symbolList.length; i<j; i++){
        
        if(i % 4 == 0) { // Indesætter et <br> tag for hvert fjerde element.
            content +='<br>'
        }
        /* Der genereres 3 tilfældige baggrundsfarver. */
        randCol = 'background: radial-gradient(';                       // Baggrund gradient type
        randCol += "#" + Math.random().toString(16).slice(2, 8);        // gradientens 1. farve
        randCol += ",#" + Math.random().toString(16).slice(2, 8);       // gradientens 2. farve
        randCol += ",#" + Math.random().toString(16).slice(2, 8)+')';   // gradientens 3. farve
        content += '<div class="flipContainer">\
                    <div data-val="'+symbolList[i]+'" class="flipper" onclick="turnOver(this)">\
                        <div class="front" style="'+randCol+'"></div>\
                        <div class="back"><img class="backPict" src="'+symbolList[i]+'"></div>\
                    </div>\
                </div>';
    }
    content += '<div id="info">&nbsp;</div>';
    content += '<div id="controls"><span class="ctrl" id="newGame" onclick="run()">Nyt spil</span></div>';
    document.getElementById('playboard').innerHTML = content;
}
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
function turnOver(elm){
    
    // Hvis der klikkes en flise der ikke er parret endnu, skal der ikke ske noget
    if(turned.length && turned[0] === elm) return;
    
    // Tæl antal vendte fliser op
    totalNumTurns++;
    document.getElementById('info').innerHTML = "Antal vendte kort: "+totalNumTurns;                
    for(var i=0, j=finished.length; i<j; i++){
        if(elm.dataset.val == finished[i]) return;
    }
    elm.classList.toggle('turn');
    turned.push(elm);
    if(flipVal==0){
        flipVal=elm.dataset.val;
        return
    }
    else{
        if(flipVal===elm.dataset.val){
            finished.push(flipVal);
            turned=[];
            flipVal=0;
            return;
        }
        else {
            flipVal=0;
            setTimeout(function(){
                var i=turned.length;
                while(--i>=0){
                    turned[i].classList.toggle('turn');
                    turned.pop();
                }
            }, 700);
        }
    }
}


document.addEventListener("DOMContentLoaded", gameInit);
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/